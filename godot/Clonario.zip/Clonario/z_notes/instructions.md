- Retirer les noeuds barres d'énergie
- Retirer les noeuds générateur
- Retirer le brain des cellules
- 


# Étapes de reconstruction
## Joueur
  - ajouter une cellule à monde
  - Afficher
  - Ajouter une camera2d à la cellule
  - Tester
  - Ajouter un noeud "ControleurJoueur"
  - Tester
  - Renommer "Cell" pour "Joueur"

## Bouffe
  - Ajouter une bouffe dans le monde
  - Tester
  - Dupliquer deux-trois fois
  - Tester
  - Si j'en veux 10, 100, 250?
    - Vais-je copier-coller?
	- J'ai créé un générateur
  - Glisser la scène "gen_bouffe.tscn" dans le monde
  - Renommer pour "GenerateurBouffe"
  - Tester
 
# Cellules
  - Ajouter une cellule dans le monde
  - Tester
  - Ajouter une noeud enfant "ControleurCellule"
  - Tester
  - Dans la même perspective que le générateur de bouffe, j'ai créer un générateur
  - Supprimer la cellule
  - Ajouter la scène "gen_cellule" dans le monde
  - Renommer pour "GenerateurCellule"
